package holamundo;

public class printholamundo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// SUBO LA CLASE A GITHUB.
	}

}
