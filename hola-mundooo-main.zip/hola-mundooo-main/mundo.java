public class mundo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// SUBO LA CLASE A GITHUB.
		System.out.println("¡Hola, Mundo!");
		//Modificado por María José
		System.out.println("¡Soy María José");
	}
}
